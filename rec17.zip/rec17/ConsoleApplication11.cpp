﻿#include <iostream>
#include <string>

using namespace std;

int recnum(const string& stroka, int& ind) {
    if (ind >= stroka.length() || !isdigit(stroka[ind]))
        return 0;

    int num = stroka[ind++] - '0'; // Преобразуем символ в число
    int next = recnum(stroka, ind); // Читаем следующие цифры

    return next == 0 ? num : num * 10 + next; // Собираем многозначное число
}


int delen(const string& stroka, int& ind, int left) {
    if (ind >= stroka.length()) return left;

    char op = stroka[ind];
    if (op != '*' && op != '/') return left;

    ind++; 
    int right = recnum(stroka, ind);

    if (op == '*') return delen(stroka, ind, left * right);
    if (op == '/') {
        if (right == 0) {
            cout << "Ошибка: деление на 0!" << endl;
            exit(1);
        }
        return delen(stroka, ind, left / right);
    }
    return left;
}

int primer(const string& stroka, int& ind, int left) {
    if (ind >= stroka.length()) return left;

    char op = stroka[ind];
    if (op != '+' && op != '-') return left;

    ind++; 
    int right = delen(stroka, ind, recnum(stroka, ind));

    if (op == '+') return primer(stroka, ind, left + right);
    if (op == '-') return primer(stroka, ind, left - right);

    return left;
}

int main() {
    setlocale(LC_ALL, "RU");
    string s;
    cout << "Введите выражение:" << endl;
    cin >> s;

    int ind = 0;
    int res = primer(s, ind, delen(s, ind, recnum(s, ind)));
    cout << "Результат: " << res << endl;

    return 0;
}
