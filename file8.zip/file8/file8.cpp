﻿//File8. Даны имена двух файлов вещественных чисел. Известно, что первый из них существует и
//является непустым, а второй в текущем каталоге отсутствует.Создать отсутствующий файл и
//записать в него начальный и конечный элементы существующего файла(в указанном порядке).
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;


int main() {
	setlocale(LC_ALL, "RU");
	ofstream file1("data.bin", ios::binary);
	vector<float> a ={ 45.2, 51.3, 1.5,5.3,58.9,20.5,30.5 };
	if (file1.is_open())
		file1.write(reinterpret_cast<char*>(a.data()),a.size()*sizeof(float));
	file1.close();
	ifstream fileout("data.bin", ios::binary);
	float num;
	vector<float> out;
	while(fileout.read(reinterpret_cast<char*>(&num), sizeof(num))) {
		out.push_back(num);}
	fileout.close();
	cout << "Числа в первом файле " << endl;
	for (float k : out) {
		cout << k << " ";
	}
	cout << endl;
	float f, l;
	ifstream filer("data.bin", ios::binary);
	filer.seekg(0, ios::beg);
	filer.read(reinterpret_cast<char*>(&f),sizeof(f)); //чтение первого
	filer.seekg(-long(sizeof(l)),ios::end);
	filer.read(reinterpret_cast<char*>(&l), sizeof(l)); //чтение последнего
	filer.close();
	ofstream file2("dataout.bin", ios::binary);
	if (file2.is_open()) {
		file2.write(reinterpret_cast<char*>(&f), sizeof(f));
		file2.write(reinterpret_cast<char*>(&l), sizeof(l));
	}
	file2.close();
	ifstream file2out("dataout.bin", ios::binary);
	cout << "Числа во втором файле: " << endl;
	while (file2out.read(reinterpret_cast<char*>(&num), sizeof(num))) {
		cout<< num << " ";
	}

	return 0;
}