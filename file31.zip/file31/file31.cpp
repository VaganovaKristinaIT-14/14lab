﻿//File31.Дан файл целых чисел, содержащий более 50 элементов.Уменьшить его размер до 50 элементов, 
// удалив из файла необходимое количество начальных элементов.
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main() {
	setlocale(LC_ALL, "RU");
	ofstream file("data.bin", ios::binary);
	vector<int> numbers;
	for (int i = 1; i <= 70; i++) {
		numbers.push_back(i * 2);
	}
	file.write(reinterpret_cast<char*>(numbers.data()), numbers.size() * sizeof(int));
	file.close();
	ifstream fileread("data.bin", ios::binary);
	cout << "Числа в исходном файле:  " << endl;
	int num;
	while (fileread.read(reinterpret_cast<char*>(&num), sizeof(num))) {
		cout << num << " ";
	}
	cout << endl;
	fileread.close();
	ifstream fileinp("data.bin", ios::binary);
	vector <int> newnum;
	int value;
	while (fileinp.read(reinterpret_cast<char*>(&value), sizeof(value))) {
		newnum.push_back(value);
	}
	fileinp.close();
	while (newnum.size() > 50) {
		newnum.erase(newnum.begin(),newnum.begin()+(newnum.size()-50));
	}
	ofstream outfile("data.bin", ios::binary);
	outfile.write(reinterpret_cast<char*>(newnum.data()), newnum.size() * sizeof(int));
	cout << "Количество чисел уменьшено до 50" << endl;
	outfile.close();
	ifstream rfile("data.bin", ios::binary);
	cout << "Числа в новом файле:  " << endl;
	while (rfile.read(reinterpret_cast<char*>(&num), sizeof(num))) {
		cout << num << " ";
	}
	cout << endl;
return 0;
}